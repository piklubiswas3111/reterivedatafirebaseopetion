package westbengal.book.Adpate;

public class class1modal {
    private String pdfname,pdflinl;

    public class1modal() {
    }

    public class1modal(String pdfname, String pdflinl) {
        this.pdfname = pdfname;
        this.pdflinl = pdflinl;
    }

    public String getPdfname() {
        return pdfname;
    }

    public void setPdfname(String pdfname) {
        this.pdfname = pdfname;
    }

    public String getPdflinl() {
        return pdflinl;
    }

    public void setPdflinl(String pdflinl) {
        this.pdflinl = pdflinl;
    }
}
