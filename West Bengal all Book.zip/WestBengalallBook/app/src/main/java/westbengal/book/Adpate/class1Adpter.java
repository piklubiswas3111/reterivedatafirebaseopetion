package westbengal.book.Adpate;

import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import westbengal.book.R;

public class class1Adpter extends FirebaseRecyclerOptions<class1modal,class1Adpter.class1holder> {


    public class class1holder extends RecyclerView.ViewHolder {
        TextView pdfname;
        Button pdfdownload;
        public class1holder(@NonNull View itemView) {
            super(itemView);
            pdfname=itemView.findViewById(R.id.class1pdfname);
            pdfdownload=itemView.findViewById(R.id.class1pdfdownload);
        }
    }
}
